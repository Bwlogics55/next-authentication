import React from 'react'

const Button = () => {
  return (
    <>
      <h1>Button</h1>
    </>
  )
}

export default Button
