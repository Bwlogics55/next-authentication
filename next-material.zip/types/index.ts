import { MouseEventHandler } from "react";

export interface CustomButtonProps {
    buttonStyle?: string;
    text: string;
    variant?: string;
    style?: string;
}